/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package quadradomagico;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
/**
 *
 * @author Adilson
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;

    @FXML
    private TextField tx_um;

    @FXML
    private TextField tx_dois;

    @FXML
    private TextField tx_tres;

    @FXML
    private TextField tx_quatro;

    @FXML
    private TextField tx_cinco;

    @FXML
    private TextField tx_seis;

    @FXML
    private TextField tx_sete;

    @FXML
    private TextField tx_oito;

    @FXML
    private TextField tx_nove;

    @FXML
    private Button btn_limpar;

    @FXML
    private Button btn_sair;
    
    @FXML
    void Limpar(ActionEvent event) {
        tx_um.setText("");
        tx_dois.setText("");
        tx_tres.setText("");
        tx_quatro.setText("");
        tx_cinco.setText("");
        tx_seis.setText("");
        tx_sete.setText("");
        tx_oito.setText("");
        tx_nove.setText("");
    }
    @FXML
    void sairSistema(ActionEvent event) {
    Platform.exit();
    }
    @FXML
    void conferir(ActionEvent event) {
    boolean acertou = true;
        int num1 = Integer.parseInt(tx_um.getText());
        int num2 = Integer.parseInt(tx_dois.getText());
        int num3 = Integer.parseInt(tx_tres.getText());
        int num4 = Integer.parseInt(tx_quatro.getText());
        int num5 = Integer.parseInt(tx_cinco.getText());
        int num6 = Integer.parseInt(tx_seis.getText());
        int num7 = Integer.parseInt(tx_sete.getText());
        int num8 = Integer.parseInt(tx_oito.getText());
        int num9 = Integer.parseInt(tx_nove.getText());
    //primeira linha 
    int somadesejada = 15;
    int soma1linha = num1 + num2 + num3;
    int soma2linha = num4 + num5 + num6;
    int soma3linha = num7 + num8 + num9;
    int soma1coluna = num1 + num4 + num7;
    int soma2coluna = num2 + num5 + num8;
    int soma3coluna = num3 + num6 + num9;
    int somadiagonalprincipal = num1 + num5 + num9;
    int somadiagonalsecundaria = num3 + num5 + num7;
    
    Alert alert = new Alert(Alert.AlertType.INFORMATION);
    
    if (somadesejada == soma1linha && soma1linha == soma2linha && soma2linha == soma3linha && soma3linha == soma1coluna
            && soma1coluna == soma2coluna && soma2coluna == soma3coluna && soma3coluna == somadiagonalprincipal && somadiagonalprincipal == somadiagonalsecundaria ){
        //System.out.println("Parabéns! Quadrado mágico preenchido corretamente!");
        alert.setContentText(" \"Parabéns! Quadrado mágico preenchido corretamente!\" ");
        alert.showAndWait();
        } else{
            alert.setContentText("Não foi dessa vez tente novamente");
            alert.showAndWait();
            
       }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
